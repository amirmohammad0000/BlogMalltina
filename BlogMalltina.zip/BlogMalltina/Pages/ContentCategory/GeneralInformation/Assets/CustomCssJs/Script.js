"use strict";

//////////////////////////////////////////////////////////////// Start Variables
let SectionChangeTheme = document.querySelector(".section_change_theme");
let SectionAppBlog = document.querySelector(".section_app_blog");
let SectionHeaderBlog = document.querySelector(".section_header_blog");
let SectionInnerSectionHeaderBlog = document.querySelectorAll(
  ".section_inner_section_header_blog"
);
let SectionInnerSectionHeaderBlogA = document.querySelectorAll(
  ".section_inner_section_header_blog a"
);
let SectionFooterBlog = document.querySelectorAll(".section_footer_blog p");
let TextSectionContentBlog = document.querySelector(
  ".text_section_content_blog"
);
let TextSectionContentBlogSpan = document.querySelector(
  ".text_section_content_blog span"
);
let SectionInnerContentBlog = document.querySelector(
  ".section_inner_content_blog"
);
let SectionPostSectionInnerContentBlog = document.querySelectorAll(
  ".section_post_section_inner_content_blog"
);
let SectionPostSectionInnerContentBlogA = document.querySelectorAll(
  ".section_post_section_inner_content_blog a"
);
let TextContentSectionPostSectionInnerContentBlog = document.querySelectorAll(
  ".text_content_section_post_section_inner_content_blog"
);
let SectionRowSectionInnerContentBlog = document.querySelectorAll(
  ".section_row_section_inner_content_blog"
);
let SectionButtonLoadMoreSectionInnerContentBlog = document.querySelector(
  ".section_button_load_more_section_inner_content_blog"
);
let SectionFooterSectionInnerContentBlog = document.querySelector(
  ".section_footer_section_inner_content_blog"
);
let SectionMenuSectionInnerSectionHeaderBlogNews = document.querySelector(
  ".section_menu_section_inner_section_header_blog_news"
);
let SectionMenuSectionInnerSectionHeaderBlogContent = document.querySelector(
  ".section_menu_section_inner_section_header_blog_content"
);
let TagASectionMenuSectionInnerSectionHeaderBlogNews =
  document.querySelectorAll(
    ".tag_a_menu_section_menu_section_inner_section_header_blog_news"
  );
let TagASectionMenuSectionInnerSectionHeaderBlogContent =
  document.querySelectorAll(
    ".tag_a_section_menu_section_inner_section_header_blog_content"
  );
let TextHeaderSectionPostSectionMainSectionInnerContentBlog =
  document.querySelectorAll(
    ".text_header_section_post_section_main_section_inner_content_blog"
  );
let SectionPostSectionMainSectionInnerContentBlog = document.querySelectorAll(
  ".section_post_section_main_section_inner_content_blog"
);
let TextContentSectionPostSectionMainSectionInnerContentBlog =
  document.querySelectorAll(
    ".text_content_section_post_section_main_section_inner_content_blog"
  );
let SectionButtonSectionPostSectionMainSectionInnerContentBlog =
  document.querySelectorAll(
    ".section_button_section_post_section_main_section_inner_content_blog"
  );
let SectionTagSectionMainSectionInnerContentBlog = document.querySelector(
  ".section_tag_section_main_section_inner_content_blog"
);
let SectionPostsSectionMainSectionInnerContentBlog = document.querySelector(
  ".section_posts_section_main_section_inner_content_blog"
);
let StatusTheme = true;
//////////////////////////////////////////////////////////////// End Variables

//////////////////////////////////////////////////////////////// Start Function Change Theme
SectionChangeTheme.addEventListener("click", () => {
  if (StatusTheme) {
    FuncSetThemeTrue();
    StatusTheme = false;
  } else {
    FuncSetThemeFalse();
    StatusTheme = true;
  }
});

const FuncSetThemeTrue = () => {
  SectionAppBlog.style.backgroundColor = "#1B2836";
  SectionAppBlog.style.color = "#459BE6";
  SectionHeaderBlog.style.borderColor = "#394654";
  SectionInnerSectionHeaderBlog.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionInnerSectionHeaderBlogA.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionFooterBlog.forEach((element) => {
    element.style.color = "#f9fcff";
  });
  TextSectionContentBlog.style.color = "#f9fcff";
  TextSectionContentBlogSpan.style.color = "#f9fcff";
  SectionInnerContentBlog.style.backgroundColor = "#1B2836";
  SectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "#394654";
  });
  SectionPostSectionInnerContentBlogA.forEach((element) => {
    element.style.color = "#459BE6";
  });
  TextContentSectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.color = "#DAFFFF";
  });
  SectionRowSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "#394654";
  });
  SectionButtonLoadMoreSectionInnerContentBlog.style.color = "#459BE6";
  SectionFooterSectionInnerContentBlog.style.backgroundColor = "#1B2836";
  SectionMenuSectionInnerSectionHeaderBlogNews.style.backgroundColor =
    "#1B2836";
  SectionMenuSectionInnerSectionHeaderBlogContent.style.backgroundColor =
    "#1B2836";
  TagASectionMenuSectionInnerSectionHeaderBlogNews.forEach((element) => {
    element.style.color = "#459BE6";
  });
  TagASectionMenuSectionInnerSectionHeaderBlogContent.forEach((element) => {
    element.style.color = "#459BE6";
  });
  TextHeaderSectionPostSectionMainSectionInnerContentBlog.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionPostSectionMainSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "#394654";
  });
  TextContentSectionPostSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "#eee";
    }
  );
  SectionButtonSectionPostSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "#459BE6";
    }
  );
  SectionTagSectionMainSectionInnerContentBlog.style.color = "#eee";
  SectionTagSectionMainSectionInnerContentBlog.style.borderBottomColor =
    "#394654";
  SectionPostsSectionMainSectionInnerContentBlog.style.borderColor = "#394654";
};

const FuncSetThemeFalse = () => {
  SectionAppBlog.style.backgroundColor = "";
  SectionAppBlog.style.color = "";
  SectionHeaderBlog.style.borderColor = "";
  SectionInnerSectionHeaderBlog.forEach((element) => {
    element.style.color = "";
  });
  SectionInnerSectionHeaderBlogA.forEach((element) => {
    element.style.color = "";
  });
  SectionFooterBlog.forEach((element) => {
    element.style.color = "";
  });
  TextSectionContentBlog.style.color = "";
  TextSectionContentBlogSpan.style.color = "";
  SectionInnerContentBlog.style.backgroundColor = "";
  SectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "";
  });
  SectionPostSectionInnerContentBlogA.forEach((element) => {
    element.style.color = "";
  });
  TextContentSectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.color = "";
  });
  SectionRowSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "";
  });
  SectionButtonLoadMoreSectionInnerContentBlog.style.color = "";
  SectionFooterSectionInnerContentBlog.style.backgroundColor = "";
  SectionMenuSectionInnerSectionHeaderBlogNews.style.backgroundColor = "";
  SectionMenuSectionInnerSectionHeaderBlogContent.style.backgroundColor = "";
  TagASectionMenuSectionInnerSectionHeaderBlogNews.forEach((element) => {
    element.style.color = "";
  });
  TagASectionMenuSectionInnerSectionHeaderBlogContent.forEach((element) => {
    element.style.color = "";
  });
  TextHeaderSectionPostSectionMainSectionInnerContentBlog.forEach((element) => {
    element.style.color = "";
  });
  SectionPostSectionMainSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "";
  });
  TextContentSectionPostSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "";
    }
  );
  SectionButtonSectionPostSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "";
    }
  );
  SectionTagSectionMainSectionInnerContentBlog.style.color = "";
  SectionTagSectionMainSectionInnerContentBlog.style.borderBottomColor = "";
  SectionPostsSectionMainSectionInnerContentBlog.style.borderColor = "";
};
//////////////////////////////////////////////////////////////// End Function Change Theme

//////////////////////////////////////////////////////////////// Start Function Button Load More
SectionButtonLoadMoreSectionInnerContentBlog.addEventListener(
  "click",
  () => {}
);
//////////////////////////////////////////////////////////////// End Function Button Load More
